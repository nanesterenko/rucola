from setuptools import setup, find_packages

setup(
    name='rucola',
    version='1.0.0',
    url='https://github.com/nanesterenko/rucola',
    author='Antenna921',
    description='Description of my package',
    packages=find_packages(),
    install_requires=['args>=0.1.0', 'kwargs>=1.0.1']
)
